"""
Scénario Admin - Simule toutes les opérations d'administration.
Ordre: Auth → Doctor CRUD → Appointments → Patients → Ratings →
       Cancellations → Planning → Clients → Statistics →
       Phone Numbers → Activity Zones → Logs
"""

from config import ADMIN_EMAIL, DOCTOR_EMAIL, DOCTOR_PASSWORD


def run(client):
    """Exécute le flow Admin complet."""
    print("\n" + "=" * 60)
    print("🔑 ADMIN FLOW")
    print("=" * 60)

    # ── 1-Auth ───────────────────────────────────────────────

    client.step(
        name="Admin JWT with email (Dev & Stg)",
        method="GET",
        path="/auth/devGetJWTWithEmail",
        body_type="form",
        body={"email": ADMIN_EMAIL},
        stores=[
            ("json.accessToken", "tokenAdmin"),
        ],
        assertions=[
            {"type": "contains", "value": "accessToken"},
        ],
    )

    # ── 2-Doctor CRUD ────────────────────────────────────────

    doctor_body = {
        "email": DOCTOR_EMAIL,
        "password": DOCTOR_PASSWORD,
        "firstName": "doc1FirstName",
        "lastName": "doc1LastName",
        "phoneNumber": "000",
        "phoneNumberCountryCode": "000",
        "phoneNumberWithCountryCode": "000",
        "pulseMedicaCalendarId": "000",
        "presentation": "doc1",
        "specialty": "GENERALIST",
        "pulseMedicaUnitId": "000",
        "color": "AAABBB",
    }

    # Fail: create doc (bad validation)
    client.step(
        name="Create doc (should fail - validation)",
        method="POST",
        path="/doctors",
        body=doctor_body,
        auth_token="{{tokenAdmin}}",
        expect_status=400,
        assertions=[
            {"type": "equal", "path": "json.errorMessage[0]",
             "value": "email must be an email"},
            {"type": "equal", "path": "json.errorMessage[1]",
             "value": "password must be longer than or equal to 8 characters"},
        ],
    )

    # Success: create doc
    client.step(
        name="Create doc (success)",
        method="POST",
        path="/doctors",
        body=doctor_body,
        auth_token="{{tokenAdmin}}",
        stores=[
            ("json.userId", "userIdDoc"),
        ],
    )

    # Fail: create doc again (duplicate)
    client.step(
        name="Create doc (should fail - duplicate)",
        method="POST",
        path="/doctors",
        body=doctor_body,
        auth_token="{{tokenAdmin}}",
        expect_status=409,
    )

    # Update doc
    client.step(
        name="Update doc",
        method="PATCH",
        path="/doctors/{{userIdDoc}}",
        body={"firstName": "doc1firstName", "lastName": "doc1lastName"},
        auth_token="{{tokenAdmin}}",
        expect_status=200,
    )

    # Fail: update doc (bad id)
    client.step(
        name="Update doc (should fail - bad id)",
        method="PATCH",
        path="/doctors/nonexistent-id",
        body={"firstName": "doc1firstName", "lastName": "doc1lastName"},
        auth_token="{{tokenAdmin}}",
        expect_status=404,
    )

    # Get doctors
    client.step(
        name="Get doctors",
        method="GET",
        path="/doctors",
        auth_token="{{tokenAdmin}}",
        assertions=[
            {"type": "istype", "path": "json.data[0].id", "value": "string"},
            {"type": "istype", "path": "json.count", "value": "number"},
        ],
    )

    # ── 3-Appointment ────────────────────────────────────────

    # Get appointments
    client.step(
        name="Get appointments",
        method="GET",
        path="/appointments",
        auth_token="{{tokenAdmin}}",
        assertions=[
            {"type": "istype", "path": "json.data[0].id", "value": "string"},
            {"type": "istype", "path": "json.count", "value": "number"},
        ],
    )

    # Get appointment by id
    client.step(
        name="Get appointment by id",
        method="GET",
        path="/appointments/{{createdAppointmentId}}",
        auth_token="{{tokenAdmin}}",
        expect_status=200,
        assertions=[
            {"type": "equal", "path": "json.id", "value": "{{createdAppointmentId}}"},
        ],
    )

    # Update appointment → SCHEDULED
    client.step(
        name="Update appointment → SCHEDULED",
        method="PATCH",
        path="/appointments/{{createdAppointmentId}}",
        body={"status": "SCHEDULED"},
        auth_token="{{tokenAdmin}}",
        expect_status=200,
        assertions=[
            {"type": "equal", "path": "json.id", "value": "{{createdAppointmentId}}"},
            {"type": "equal", "path": "json.status", "value": "SCHEDULED"},
        ],
    )

    # Fail: update appointment (bad enum)
    client.step(
        name="Update appointment (should fail - bad enum)",
        method="PATCH",
        path="/appointments/{{createdAppointmentId}}",
        body={"status": "scheduled"},  # lowercase = invalid
        auth_token="{{tokenAdmin}}",
        expect_status=400,
        assertions=[
            {"type": "equal", "path": "json.errorMessage[0]",
             "value": "status must be a valid enum value"},
        ],
    )

    # ── 4-Patient ────────────────────────────────────────────

    # Get patients
    client.step(
        name="Get patients",
        method="GET",
        path="/patients",
        auth_token="{{tokenAdmin}}",
        expect_status=200,
        assertions=[
            {"type": "istype", "path": "json.data[0].id", "value": "string"},
        ],
    )

    # Get patient by id
    client.step(
        name="Get patient by id",
        method="GET",
        path="/patients/{{createdPatientId}}",
        auth_token="{{tokenAdmin}}",
        expect_status=200,
        assertions=[
            {"type": "equal", "path": "json.id", "value": "{{createdPatientId}}"},
        ],
    )

    # ── 5-Rating ─────────────────────────────────────────────

    # Get appointment ratings
    client.step(
        name="Get appointment ratings",
        method="GET",
        path="/ratings/ratingsByType",
        params={"filter": '{"type":"appointment"}'},
        auth_token="{{tokenAdmin}}",
        expect_status=200,
        assertions=[
            {"type": "istype", "path": "json.data[0].id", "value": "string"},
            {"type": "istype", "path": "json.count", "value": "number"},
        ],
    )

    # Get app ratings
    client.step(
        name="Get app ratings",
        method="GET",
        path="/ratings/ratingsByType",
        params={"filter": '{"type":"app"}'},
        auth_token="{{tokenAdmin}}",
        expect_status=200,
        assertions=[
            {"type": "istype", "path": "json.data[0].id", "value": "string"},
            {"type": "istype", "path": "json.count", "value": "number"},
        ],
    )

    # Get appointment rating by id
    client.step(
        name="Get appointment rating by id",
        method="GET",
        path="/ratings/appointment/{{appointmentRatingId}}",
        auth_token="{{tokenAdmin}}",
        expect_status=200,
        assertions=[
            {"type": "istype", "path": "json.id", "value": "string"},
        ],
    )

    # Get all appointment ratings
    client.step(
        name="Get all appointment ratings",
        method="GET",
        path="/ratings/appointment",
        auth_token="{{tokenAdmin}}",
        expect_status=200,
        assertions=[
            {"type": "istype", "path": "json.data[0].id", "value": "string"},
            {"type": "istype", "path": "json.count", "value": "number"},
        ],
    )

    # Update rating
    client.step(
        name="Update rating (admin comment)",
        method="PATCH",
        path="/ratings/appointment/{{appointmentRatingId}}",
        body={"adminComment": "test"},
        auth_token="{{tokenAdmin}}",
        expect_status=200,
        assertions=[
            {"type": "equal", "path": "json.id", "value": "{{appointmentRatingId}}"},
            {"type": "equal", "path": "json.adminComment", "value": "test"},
        ],
    )

    # ── 6-Cancellation ───────────────────────────────────────

    # Cancel appointment
    client.step(
        name="Cancel appointment",
        method="PATCH",
        path="/appointments/{{createdAppointmentId}}",
        body={"status": "CANCELLED"},
        auth_token="{{tokenAdmin}}",
        expect_status=200,
        assertions=[
            {"type": "equal", "path": "json.id", "value": "{{createdAppointmentId}}"},
            {"type": "equal", "path": "json.status", "value": "CANCELLED"},
        ],
    )

    # Get cancellation by id
    client.step(
        name="Get cancellation by id",
        method="GET",
        path="/appointments/cancellations/{{createdAppointmentId}}",
        auth_token="{{tokenAdmin}}",
        expect_status=200,
        assertions=[
            {"type": "equal", "path": "json.id", "value": "{{createdAppointmentId}}"},
        ],
    )

    # Get all cancellations
    client.step(
        name="Get cancellations",
        method="GET",
        path="/appointments/cancellations",
        auth_token="{{tokenAdmin}}",
        expect_status=200,
    )

    # ── 7-Planning ───────────────────────────────────────────

    client.step(
        name="Get plannings",
        method="GET",
        path="/doctorsPlanning",
        auth_token="{{tokenAdmin}}",
        expect_status=200,
        assertions=[
            {"type": "istype", "path": "json.data[0].id", "value": "string"},
            {"type": "istype", "path": "json.count", "value": "number"},
        ],
    )

    # ── 8-Client ─────────────────────────────────────────────

    # Get clients (search)
    client.step(
        name="Get clients (search 'hon')",
        method="GET",
        path="/users/clients",
        params={
            "filter": '{"q":"hon"}',
            "order": "DESC",
            "sort": "createdAt",
        },
        auth_token="{{tokenAdmin}}",
        expect_status=200,
        assertions=[
            {"type": "istype", "path": "json.data[0].id", "value": "string"},
            {"type": "istype", "path": "json.count", "value": "number"},
        ],
    )

    # Update client (blacklist)
    client.step(
        name="Update client (blacklist)",
        method="PATCH",
        path="/users/clients/{{userId}}",
        body={"blackListed": True},
        auth_token="{{tokenAdmin}}",
        expect_status=200,
    )

    # Get client by id
    client.step(
        name="Get client by id",
        method="GET",
        path="/users/clients/{{userId}}",
        auth_token="{{tokenAdmin}}",
        expect_status=200,
        assertions=[
            {"type": "istype", "path": "json.id", "value": "string"},
        ],
    )

    # Waiting list clients
    client.step(
        name="Get waiting list clients",
        method="GET",
        path="/users/waitingListClients",
        auth_token="{{tokenAdmin}}",
        expect_status=200,
        assertions=[
            {"type": "istype", "path": "json.data[0].id", "value": "string"},
            {"type": "istype", "path": "json.count", "value": "number"},
        ],
    )

    # ── 9-Statistics ─────────────────────────────────────────

    client.step(
        name="Get doctor statistics",
        method="GET",
        path="/doctors/statistics/{{userIdDoc}}",
        auth_token="{{tokenAdmin}}",
        expect_status=200,
        assertions=[
            {"type": "istype", "path": "json.data[0].id", "value": "string"},
            {"type": "equal", "path": "json.data[0].id", "value": "appointments"},
        ],
    )

    # ── 10-Docadom Phone Number ──────────────────────────────

    # Create phone number
    client.step(
        name="Create docadom phone number",
        method="POST",
        path="/docadomPhoneNumbers",
        body_type="form",
        body={
            "phoneNumber": "0000000000",
            "phoneNumberCountryCode": "41",
            "isActive": "true",
        },
        auth_token="{{tokenAdmin}}",
        expect_status=201,
        stores=[
            ("json.id", "docadomPhoneNumberId"),
        ],
    )

    # Fail: create duplicate
    client.step(
        name="Create docadom phone number (should fail - duplicate)",
        method="POST",
        path="/docadomPhoneNumbers",
        body_type="form",
        body={
            "phoneNumber": "0000000000",
            "phoneNumberCountryCode": "41",
            "isActive": "false",
        },
        auth_token="{{tokenAdmin}}",
        expect_status=409,
    )

    # Get phone numbers
    client.step(
        name="Get docadom phone numbers",
        method="GET",
        path="/docadomPhoneNumbers",
        auth_token="{{tokenAdmin}}",
        expect_status=200,
        assertions=[
            {"type": "istype", "path": "json.data[0].id", "value": "string"},
            {"type": "istype", "path": "json.count", "value": "number"},
        ],
    )

    # Get phone number by id
    client.step(
        name="Get docadom phone number by id",
        method="GET",
        path="/docadomPhoneNumbers/{{docadomPhoneNumberId}}",
        auth_token="{{tokenAdmin}}",
        expect_status=200,
        assertions=[
            {"type": "istype", "path": "json.id", "value": "string"},
        ],
    )

    # Update phone number
    client.step(
        name="Update docadom phone number",
        method="PATCH",
        path="/docadomPhoneNumbers/{{docadomPhoneNumberId}}",
        body={"isActive": False},
        auth_token="{{tokenAdmin}}",
        expect_status=200,
        assertions=[
            {"type": "equal", "path": "json.id", "value": "{{docadomPhoneNumberId}}"},
        ],
    )

    # ── 11-Activity Zone ─────────────────────────────────────

    client.step(
        name="Get activity zones",
        method="GET",
        path="/activityZones",
        auth_token="{{tokenAdmin}}",
        expect_status=200,
        assertions=[
            {"type": "istype", "path": "json.data[0].id", "value": "string"},
        ],
    )

    # ── 12-Log ───────────────────────────────────────────────

    client.step(
        name="Get logs",
        method="GET",
        path="/client-logs",
        auth_token="{{tokenAdmin}}",
        expect_status=404,
    )

    print("\n✅ Admin flow complete")
