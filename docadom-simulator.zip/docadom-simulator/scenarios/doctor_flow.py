"""
Scénario Doctor - Simule le parcours d'un médecin.
Ordre: Auth → Doctor CRUD → Appointment management
"""

from config import DOCTOR_EMAIL


def run(client):
    """Exécute le flow Doctor complet."""
    print("\n" + "=" * 60)
    print("🩺 DOCTOR FLOW")
    print("=" * 60)

    # ── 1-Auth ───────────────────────────────────────────────

    client.step(
        name="Doc JWT with email (Dev & Stg)",
        method="GET",
        path="/auth/devGetJWTWithEmail",
        body_type="form",
        body={"email": DOCTOR_EMAIL},
        stores=[
            ("json.accessToken", "tokenDoc"),
            ("json.userId", "userIdDoc"),
        ],
        assertions=[
            {"type": "contains", "value": "accessToken"},
        ],
    )

    # ── 2-Doctor ─────────────────────────────────────────────

    # Doc update (connexion + phone)
    client.step(
        name="Doc update",
        method="PATCH",
        path="/doctors/{{userIdDoc}}",
        body={
            "lastConnection": "2023-05-15T16:03:31.229Z",
            "docadomPhoneNumber": "000",
            "isConnected": True,
        },
        auth_token="{{tokenDoc}}",
        expect_status=200,
        assertions=[
            {"type": "equal", "path": "json.docadomPhoneNumber", "value": "000"},
        ],
    )

    # Doc update latest position
    client.step(
        name="Doc update latest position",
        method="PATCH",
        path="/users/latestPosition/{{userIdDoc}}",
        body={"lat": 47, "long": 6},
        auth_token="{{tokenDoc}}",
        assertions=[
            {"type": "istype", "path": "json.firstName", "value": "string"},
            {"type": "equal", "path": "json.latestPosition.lat", "value": "47"},
        ],
    )

    # Doc info by id
    client.step(
        name="Doc info by id",
        method="GET",
        path="/doctors/{{userIdDoc}}",
        auth_token="{{tokenDoc}}",
        expect_status=200,
        assertions=[
            {"type": "equal", "path": "json.id", "value": "{{userIdDoc}}"},
        ],
    )

    # ── 3-Appointment ────────────────────────────────────────

    # Doc get patients
    client.step(
        name="Doc get patients by id",
        method="GET",
        path="/patients/getPatients/{{userIdDoc}}",
        auth_token="{{tokenDoc}}",
        expect_status=200,
    )

    # Doc update appointment → SCHEDULED
    client.step(
        name="Doc update appointment → SCHEDULED",
        method="PATCH",
        path="/appointments/{{createdAppointmentId}}",
        body={"status": "SCHEDULED"},
        auth_token="{{tokenDoc}}",
        expect_status=200,
        assertions=[
            {"type": "equal", "path": "json.status", "value": "SCHEDULED"},
        ],
    )

    # Doc prioritize appointment (should fail)
    client.step(
        name="Doc prioritize appointment (should fail)",
        method="POST",
        path="/appointments/prioritizeAppointment/{{createdAppointmentId}}",
        auth_token="{{tokenDoc}}",
        expect_status=404,
        assertions=[
            {"type": "equal", "path": "json.errorMessage",
             "value": "doctor has no scheduled appointment"},
        ],
    )

    # Doc get appointment by id
    client.step(
        name="Doc appointment by id",
        method="GET",
        path="/appointments/{{createdAppointmentId}}",
        auth_token="{{tokenDoc}}",
        expect_status=200,
        assertions=[
            {"type": "equal", "path": "json.id", "value": "{{createdAppointmentId}}"},
        ],
    )

    print("\n✅ Doctor flow complete")
