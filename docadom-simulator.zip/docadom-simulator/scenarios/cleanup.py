"""
Cleanup - Nettoie toutes les données de test créées.
Ordre: Anonymize patient → Anonymize user → Delete doctor → Delete phone number
"""


def run(client):
    """Exécute le cleanup complet."""
    print("\n" + "=" * 60)
    print("🧹 CLEANUP")
    print("=" * 60)

    # Anonymize patient
    client.step(
        name="Anonymize patient",
        method="POST",
        path="/patients/anonymize",
        body_type="form",
        body={"id": "{{createdPatientId}}"},
        auth_token="{{token}}",
        assertions=[
            {"type": "equal", "path": "json.lastName", "value": "ANONYMOUS"},
        ],
    )

    # Anonymize user and their patients
    client.step(
        name="Anonymize user and their patients",
        method="POST",
        path="/users/anonymize",
        auth_token="{{token}}",
        assertions=[
            {"type": "equal", "path": "json.lastName", "value": "ANONYMOUS"},
        ],
    )

    # Delete doctor
    client.step(
        name="Delete doctor",
        method="DELETE",
        path="/doctors/{{userIdDoc}}",
        auth_token="{{tokenAdmin}}",
        expect_status=200,
    )

    # Delete docadom phone number
    client.step(
        name="Delete docadom phone number",
        method="DELETE",
        path="/docadomPhoneNumbers/{{docadomPhoneNumberId}}",
        auth_token="{{tokenAdmin}}",
        expect_status=200,
    )

    print("\n✅ Cleanup complete")
