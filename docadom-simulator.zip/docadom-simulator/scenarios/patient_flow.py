"""
Scénario Patient - Simule le parcours complet d'un patient.
Ordre: Auth → Patient → User → Appointment → Ratings → APIs → Zone → Logs
"""

from config import (
    PATIENT_EMAIL, PATIENT_PASSWORD, PATIENT_PHONE, ACTIVITY_ZONE_ID
)


def run(client):
    """Exécute le flow Patient complet."""
    print("\n" + "=" * 60)
    print("👤 PATIENT FLOW")
    print("=" * 60)

    # ── 1-Auth ───────────────────────────────────────────────

    # Signup
    client.step(
        name="Signup",
        method="POST",
        path="/auth/signUp",
        body={
            "acceptedDoctorSharing": True,
            "acceptedTerms": True,
            "activityZone": ACTIVITY_ZONE_ID,
            "address": {
                "city": "Thunder",
                "country": "Clouds",
                "formattedAddress": "2 Rue de la foudre, 1005 Thunder, Clouds",
                "postalCode": "1005",
                "streetName": "Rue de la foudre",
                "streetNumber": "2",
            },
            "email": PATIENT_EMAIL,
            "firstName": "Lightning",
            "lastName": "Tests",
            "latestPosition": {"lat": 46.5242803, "long": 6.6326921},
            "onWaitingList": False,
            "outOfZone": False,
            "password": PATIENT_PASSWORD,
            "phoneNumber": PATIENT_PHONE,
            "phoneNumberCountryCode": "+33",
            "phoneNumberWithCountryCode": f"+33{PATIENT_PHONE}",
            "userType": "USER",
        },
        stores=[
            ("json.accessToken", "token"),
        ],
        assertions=[
            {"type": "istype", "path": "json.userId", "value": "string"},
        ],
    )

    # Signin F2A (should fail - no code yet)
    client.step(
        name="Signin F2A (should fail)",
        method="POST",
        path="/auth/signInF2A",
        body_type="form",
        body={
            "email": PATIENT_EMAIL,
            "password": PATIENT_PASSWORD,
            "deviceId": "1",
        },
        assertions=[
            {"type": "equal", "path": "json.message", "value": "No code found"},
        ],
    )

    # ── 2-Patient ────────────────────────────────────────────

    # Create patient
    client.step(
        name="Create patient",
        method="POST",
        path="/patients",
        body={
            "firstName": "John",
            "lastName": "Doe",
            "avsNumber": "7569557430607",
            "gender": "MALE",
            "birthDate": "1990-01-01",
            "cardNumber": "80756000620050025898",
            "insuranceNumber": "02531",
            "expirationDate": "2028-01-01",
            "isMyself": False,
        },
        auth_token="{{token}}",
        stores=[
            ("json.id", "createdPatientId"),
            ("json.", "createdPatient"),  # Stocke l'objet patient complet
        ],
        assertions=[
            {"type": "equal", "path": "json.firstName", "value": "John"},
        ],
    )

    # Patient update
    client.step(
        name="Patient update",
        method="POST",
        path="/patients/updatePatientAsUser",
        body_type="form",
        body={
            "id": "{{createdPatientId}}",
            "firstName": "Thundertest",
        },
        auth_token="{{token}}",
        assertions=[
            {"type": "equal", "path": "json.firstName", "value": "Thundertest"},
        ],
    )

    # ── 3-User ───────────────────────────────────────────────

    # User update
    client.step(
        name="User update",
        method="POST",
        path="/users",
        body_type="form",
        body={"firstName": "Thundertest"},
        auth_token="{{token}}",
        stores=[
            ("json.address", "createdUserAddress"),
            ("json.latestPosition", "createdUserLatestPosition"),
            ("json.id", "userId"),
        ],
        assertions=[
            {"type": "equal", "path": "json.firstName", "value": "Thundertest"},
        ],
    )

    # Check phone/email (should conflict - already exists)
    client.step(
        name="Check phone/email (should conflict)",
        method="POST",
        path="/users/checkIfPhoneAndEmailExist",
        body_type="form",
        body={
            "email": PATIENT_EMAIL,
            "phoneNumber": PATIENT_PHONE,
        },
        auth_token="{{token}}",
        expect_status=409,
    )

    # Check phone/email (should be ok - new email)
    client.step(
        name="Check phone/email (should be ok)",
        method="POST",
        path="/users/checkIfPhoneAndEmailExist",
        body_type="form",
        body={
            "email": "thundermailthatdoesnotexist@tests.com",
            "phoneNumber": "1122334455",
        },
        auth_token="{{token}}",
        expect_status=201,
    )

    # ── 4-Appointment ────────────────────────────────────────

    # Take an appointment
    client.step(
        name="Take an appointment (will fail if no doc available)",
        method="POST",
        path="/appointments",
        body={
            "address": client.state.get("createdUserAddress", {}),
            "addressCoordinates": client.state.get("createdUserLatestPosition", {}),
            "patient": client.state.get("createdPatient", {}),
            "bodyPart": "HEAD_ARM_LEGS",
            "reasonText": "Checkup",
        },
        auth_token="{{token}}",
        expect_status=201,
        stores=[
            ("json.id", "createdAppointmentId"),
            ("json.doctor.id", "createdAppointmentDoctorUserId"),
        ],
    )

    # Get the created appointment
    client.step(
        name="Get created appointment",
        method="GET",
        path="/appointments/{{createdAppointmentId}}",
        auth_token="{{token}}",
        assertions=[
            {"type": "equal", "path": "json.id", "value": "{{createdAppointmentId}}"},
        ],
    )

    # Update appointment to FINISHED
    client.step(
        name="Update appointment → FINISHED",
        method="PATCH",
        path="/appointments/{{createdAppointmentId}}",
        body={"status": "FINISHED"},
        auth_token="{{token}}",
        assertions=[
            {"type": "equal", "path": "json.id", "value": "{{createdAppointmentId}}"},
        ],
    )

    # Get all appointments of user
    client.step(
        name="Get all appointments of user",
        method="GET",
        path="/appointments/patientsAndAppointmentsOfUser",
        auth_token="{{token}}",
        expect_status=200,
    )

    # Waiting time for patient
    client.step(
        name="Get waiting time for patient",
        method="POST",
        path="/appointments/waitingTimeForPatient",
        body={
            "patient": {"id": client.state.get("createdPatientId", "")},
            "addressCoordinates": {"lat": 46, "long": 8},
        },
        auth_token="{{token}}",
        expect_status=201,
    )

    # All waiting times
    client.step(
        name="Get all waiting times",
        method="GET",
        path="/appointments/waitingTimeForAllSpecialities",
        auth_token="{{token}}",
        assertions=[
            {"type": "istype", "path": "json.generalistWaitingTime", "value": "number"},
        ],
    )

    # ── 5-Rating Appointment ─────────────────────────────────

    client.step(
        name="Rate an appointment",
        method="POST",
        path="/ratings/appointment",
        body_type="form",
        body={
            "appointmentId": "{{createdAppointmentId}}",
            "rating": "3",
            "ratingText": "It was nice",
            "ratingRefused": "false",
            "doctorUserId": "{{createdAppointmentDoctorUserId}}",
        },
        auth_token="{{token}}",
        expect_status=201,
        stores=[
            ("json.rating.id", "appointmentRatingId"),
        ],
        assertions=[
            {"type": "equal", "path": "json.rating.ratingText", "value": "It was nice"},
        ],
    )

    # ── 6-Rating App ─────────────────────────────────────────

    client.step(
        name="Rate the app",
        method="POST",
        path="/ratings/app",
        body_type="form",
        body={
            "rating": "3",
            "ratingText": "Trop bien",
            "hasRefusedToRateApp": "false",
        },
        auth_token="{{token}}",
        expect_status=201,
    )

    # ── 7-APIs ───────────────────────────────────────────────

    client.step(
        name="CoverCard check card n°",
        method="GET",
        path="/patients/covercard/80756015420150336819",
        auth_token="{{token}}",
        assertions=[
            {"type": "equal", "path": "json.covercardCode", "value": "0"},
        ],
    )

    # ── 8-Activity Zone ──────────────────────────────────────

    client.step(
        name="Check if coordinates are in a zone",
        method="POST",
        path="/activityZones/getUserZoneInfo",
        body={"lat": 46.5175524, "long": 6.633966099999999},
        assertions=[
            {"type": "istype", "path": "json.zoneUserIsIn.openToNewUsers", "value": "boolean"},
        ],
    )

    # ── 9-Log ────────────────────────────────────────────────

    client.step(
        name="Post log (should fail - logs not activated)",
        method="POST",
        path="/client-logs",
        body_type="form",
        body={
            "userId": "{{userId}}",
            "log": "log",
        },
        auth_token="{{token}}",
        expect_status=400,
        assertions=[
            {"type": "equal", "path": "json.errorMessage", "value": "Logs are not activated"},
        ],
    )

    client.step(
        name="Post log (success with valid userId)",
        method="POST",
        path="/client-logs",
        body_type="form",
        body={
            "userId": "00abb2e5-d06a-419d-a468-088a6d203d38",
            "log": "log message",
            "deviceId": "6543654ERT-ERF438",
        },
        auth_token="{{token}}",
        expect_status=201,
    )

    print("\n✅ Patient flow complete")
