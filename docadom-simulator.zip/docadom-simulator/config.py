"""
Docadom Simulator - Configuration
Modifier BASE_URL selon l'environnement cible (dev/staging).
"""

# URL de base de l'API
BASE_URL = "http://localhost:3000"

# Credentials de test
PATIENT_EMAIL = "thunder2@tests.com"
PATIENT_PASSWORD = "password1"
PATIENT_PHONE = "636401112"

DOCTOR_EMAIL = "doc1test@singularit.fr"
DOCTOR_PASSWORD = "doc1Test;"

ADMIN_EMAIL = "tech@singularit.fr"

# Activity Zone de test
ACTIVITY_ZONE_ID = "75bacc6f-df63-40a1-aec5-a77dba14b511"
