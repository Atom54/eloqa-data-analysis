#!/usr/bin/env python3
"""
Docadom Day Simulator
Simule une journée complète sur la plateforme Docadom.

Séquence:
  1. Patient flow  → Inscription, création patient, prise de RDV, ratings
  2. Admin flow    → Auth admin, gestion doctors/appointments/ratings/etc.
  3. Doctor flow   → Auth docteur, gestion de ses RDV
  4. Cleanup       → Anonymisation et suppression des données de test

Usage:
  python run.py                     # Tout lancer
  python run.py --only patient      # Un seul scénario
  python run.py --url http://...    # Autre environnement
  python run.py --skip-cleanup      # Garder les données
"""

import argparse
import sys
import time

from client import DocadomClient
from config import BASE_URL
from scenarios import patient_flow, admin_flow, doctor_flow, cleanup


def main():
    parser = argparse.ArgumentParser(description="Docadom Day Simulator")
    parser.add_argument("--url", default=BASE_URL, help="Base URL de l'API")
    parser.add_argument("--only", choices=["patient", "admin", "doctor", "cleanup"],
                        help="Lancer un seul scénario")
    parser.add_argument("--skip-cleanup", action="store_true",
                        help="Ne pas nettoyer les données après")
    args = parser.parse_args()

    client = DocadomClient(base_url=args.url)

    print("🏥 DOCADOM DAY SIMULATOR")
    print(f"   Target: {args.url}")
    print(f"   Time:   {time.strftime('%Y-%m-%d %H:%M:%S')}")

    start = time.time()

    scenarios = {
        "patient": patient_flow,
        "admin": admin_flow,
        "doctor": doctor_flow,
        "cleanup": cleanup,
    }

    if args.only:
        scenarios[args.only].run(client)
    else:
        patient_flow.run(client)
        admin_flow.run(client)
        doctor_flow.run(client)
        if not args.skip_cleanup:
            cleanup.run(client)

    elapsed = time.time() - start
    print(f"\n⏱️  Temps total: {elapsed:.1f}s")

    success = client.summary()
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
