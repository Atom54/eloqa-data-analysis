# 🏥 Docadom Day Simulator

Simulateur de journée Docadom — converti depuis la collection Thunder Client.

## Setup

```bash
pip install -r requirements.txt
```

## Configuration

Éditer `config.py` :
- `BASE_URL` → URL de l'API (dev/staging)
- Credentials de test (patient, doctor, admin)

## Usage

```bash
# Lancer la simulation complète
python run.py

# Cibler un autre environnement
python run.py --url https://api-staging.docadom.ch

# Un seul scénario
python run.py --only patient
python run.py --only admin
python run.py --only doctor

# Garder les données (pas de cleanup)
python run.py --skip-cleanup
```

## Structure

```
docadom-simulator/
├── config.py              # URL, credentials
├── client.py              # HTTP client + state + assertions
├── scenarios/
│   ├── patient_flow.py    # Signup → Patient → Appointments → Ratings
│   ├── doctor_flow.py     # Auth → Update → Manage appointments
│   ├── admin_flow.py      # Auth → Full CRUD (doctors, patients, ratings...)
│   └── cleanup.py         # Anonymize + Delete test data
├── run.py                 # Point d'entrée principal
└── requirements.txt
```

## Séquence d'exécution

1. **Patient** → Inscription, création patient, prise de RDV, ratings, zone check
2. **Admin** → Auth admin, CRUD doctors, gestion appointments/ratings/cancellations/planning/clients/stats/phones/zones/logs
3. **Doctor** → Auth doctor, update profil/position, gestion appointments
4. **Cleanup** → Anonymisation patient/user, suppression doctor + phone number

## Variables partagées

Les scénarios partagent un state commun via `client.state` :
- `token` → JWT patient
- `tokenDoc` → JWT docteur
- `tokenAdmin` → JWT admin
- `createdPatientId`, `createdPatient` → Patient créé
- `createdAppointmentId` → RDV créé
- `userId`, `userIdDoc` → IDs utilisateurs
- etc.

## Origine

Converti depuis `Docadom Tests Dev & Stg` (Thunder Client collection, mai 2023).
~50 requêtes API couvrant les 3 rôles (Patient, Doctor, Admin) + cleanup.
