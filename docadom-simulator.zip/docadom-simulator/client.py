"""
Docadom Simulator - HTTP Client
Client HTTP avec gestion d'état partagé entre les scénarios.
"""

import json
import re
import requests
from config import BASE_URL


class DocadomClient:
    """Client HTTP pour simuler les appels API Docadom."""

    def __init__(self, base_url=BASE_URL):
        self.base_url = base_url
        self.state = {}  # Variables partagées entre requêtes
        self.session = requests.Session()
        self.results = []  # Log des résultats

    # ── Résolution de variables ──────────────────────────────

    def resolve(self, template):
        """Résout les {{variable}} dans un template string."""
        if not isinstance(template, str):
            return template

        def replacer(match):
            var_name = match.group(1)
            val = self.state.get(var_name, match.group(0))
            if isinstance(val, (dict, list)):
                return json.dumps(val)
            return str(val)

        return re.sub(r"\{\{(\w+)\}\}", replacer, template)

    def resolve_json_body(self, raw):
        """Résout les variables dans un body JSON brut puis le parse."""
        resolved = self.resolve(raw)
        try:
            return json.loads(resolved)
        except json.JSONDecodeError:
            print(f"  ⚠️  JSON parse error: {resolved[:100]}...")
            return None

    # ── Extraction de valeur depuis une réponse ──────────────

    def extract(self, data, path):
        """Extrait une valeur d'un dict via un chemin dot-notation.
        Ex: 'json.doctor.id' → data['doctor']['id']
        """
        # Retirer le préfixe 'json.' (convention Thunder)
        if path.startswith("json."):
            path = path[5:]

        if not path:  # 'json.' seul = objet entier
            return data

        parts = path.split(".")
        current = data
        for part in parts:
            # Gérer les accès array comme data[0]
            array_match = re.match(r"(\w+)\[(\d+)\]", part)
            if array_match:
                key, idx = array_match.group(1), int(array_match.group(2))
                current = current[key][idx]
            else:
                current = current[part]
        return current

    # ── Requête HTTP ─────────────────────────────────────────

    def request(self, method, path, body=None, body_type="json",
                auth_token=None, params=None, name=""):
        """Exécute une requête HTTP et retourne la réponse."""
        url = f"{self.base_url}{self.resolve(path)}"
        headers = {}

        if auth_token:
            resolved_token = self.resolve(auth_token)
            headers["Authorization"] = f"Bearer {resolved_token}"

        kwargs = {"headers": headers}

        if params:
            resolved_params = {k: self.resolve(v) for k, v in params.items()}
            kwargs["params"] = resolved_params

        if body:
            if body_type == "json":
                if isinstance(body, str):
                    kwargs["json"] = self.resolve_json_body(body)
                else:
                    kwargs["json"] = body
            elif body_type == "form":
                resolved_form = {k: self.resolve(v) for k, v in body.items()}
                kwargs["data"] = resolved_form

        resp = self.session.request(method, url, **kwargs)
        return resp

    # ── Assertions ───────────────────────────────────────────

    def assert_status(self, resp, expected, name=""):
        """Vérifie le code HTTP."""
        ok = resp.status_code == expected
        symbol = "✅" if ok else "❌"
        print(f"  {symbol} Status {resp.status_code} (expected {expected})")
        if not ok:
            print(f"     Response: {resp.text[:200]}")
        return ok

    def assert_json_value(self, resp, json_path, expected, name=""):
        """Vérifie une valeur dans le JSON de réponse."""
        try:
            data = resp.json()
            actual = self.extract(data, json_path)
            resolved_expected = self.resolve(expected)
            # Comparaison flexible (string vs number)
            ok = str(actual) == str(resolved_expected)
            symbol = "✅" if ok else "❌"
            print(f"  {symbol} {json_path} = {actual} (expected {resolved_expected})")
            return ok
        except Exception as e:
            print(f"  ❌ {json_path}: {e}")
            return False

    def assert_json_type(self, resp, json_path, expected_type, name=""):
        """Vérifie le type d'une valeur JSON."""
        try:
            data = resp.json()
            actual = self.extract(data, json_path)
            type_map = {
                "string": str,
                "number": (int, float),
                "boolean": bool,
                "array": list,
                "object": dict,
            }
            expected_cls = type_map.get(expected_type, str)
            ok = isinstance(actual, expected_cls)
            symbol = "✅" if ok else "❌"
            print(f"  {symbol} {json_path} is {expected_type}")
            return ok
        except Exception as e:
            print(f"  ❌ {json_path} type check: {e}")
            return False

    def assert_body_contains(self, resp, text, name=""):
        """Vérifie que le body contient un texte."""
        ok = text in resp.text
        symbol = "✅" if ok else "❌"
        print(f"  {symbol} Body contains '{text}'")
        return ok

    # ── Store ────────────────────────────────────────────────

    def store(self, resp, json_path, var_name):
        """Extrait une valeur de la réponse et la stocke dans state."""
        # Nettoyer le nom de variable: {{varName}} → varName
        clean_name = var_name.strip("{}")
        try:
            data = resp.json()
            value = self.extract(data, json_path)
            self.state[clean_name] = value
            preview = str(value)[:60]
            print(f"  💾 {clean_name} = {preview}")
        except Exception as e:
            print(f"  ⚠️  Store {clean_name} failed: {e}")

    # ── Helper pour exécuter un step complet ─────────────────

    def step(self, name, method, path, body=None, body_type="json",
             auth_token=None, params=None,
             expect_status=None, assertions=None, stores=None):
        """Exécute un step complet: requête + assertions + stores."""
        print(f"\n🔹 {name}")
        print(f"   {method} {self.resolve(path)}")

        resp = self.request(method, path, body, body_type, auth_token, params, name)

        all_ok = True

        if expect_status:
            all_ok &= self.assert_status(resp, expect_status, name)

        if stores:
            for json_path, var_name in stores:
                self.store(resp, json_path, var_name)

        if assertions:
            for assertion in assertions:
                a_type = assertion.get("type")
                if a_type == "equal":
                    all_ok &= self.assert_json_value(
                        resp, assertion["path"], assertion["value"], name
                    )
                elif a_type == "istype":
                    all_ok &= self.assert_json_type(
                        resp, assertion["path"], assertion["value"], name
                    )
                elif a_type == "contains":
                    all_ok &= self.assert_body_contains(
                        resp, assertion["value"], name
                    )

        self.results.append({"name": name, "ok": all_ok, "status": resp.status_code})
        return resp

    # ── Résumé ───────────────────────────────────────────────

    def summary(self):
        """Affiche le résumé de tous les steps."""
        total = len(self.results)
        passed = sum(1 for r in self.results if r["ok"])
        failed = total - passed

        print("\n" + "=" * 60)
        print(f"📊 RÉSUMÉ: {passed}/{total} passed, {failed} failed")
        print("=" * 60)

        if failed > 0:
            print("\n❌ Failed steps:")
            for r in self.results:
                if not r["ok"]:
                    print(f"   - {r['name']} (HTTP {r['status']})")

        return failed == 0
